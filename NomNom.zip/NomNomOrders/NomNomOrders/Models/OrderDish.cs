﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NomNomOrders.Models
{
    [Table("order_dish")]
    public class OrderDish
    {
        [Key]
        public int Id { get; set; }
        public int Order_Id { get; set; }
        public int Dish_Id { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }

        public OrderDish() { }

        public OrderDish(int id, int order_Id, int dish_Id, int quantity, decimal price)
        {
            Id = id;
            Order_Id = order_Id;
            Dish_Id = dish_Id;
            Quantity = quantity;
            Price = price;
        }
    }
}
