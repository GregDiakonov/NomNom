﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NomNomOrders.Models
{
    [Table("dish")]
    public class Dish
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public bool Is_Available { get; set; }
        public DateTime Created_At { get; set; }
        public DateTime Updated_At { get; set; }

        public Dish() {
            Name = "";
            Description = "";
        }

        public Dish(int id, string name, string description, decimal price, int quantity, bool is_Available, DateTime created_At, DateTime updated_At)
        {
            Id = id;
            Name = name;
            Description = description;
            Price = price;
            Quantity = quantity;
            Is_Available = is_Available;
            Created_At = created_At;
            Updated_At = updated_At;
        }
    }
}
