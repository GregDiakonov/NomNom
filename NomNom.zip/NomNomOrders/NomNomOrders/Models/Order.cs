﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NomNomOrders.Models
{
    [Table("Order")]
    public class Order
    {
        [Key] 
        public int Id { get; set; }

        public int Customer_Id { get; set; }
        public string Status { get; set; }
        public string Special_Requests { get; set; }
        public DateTime Created_At { get; set; }
        public DateTime Updated_At { get; set; }

        public Order() {
            Status = string.Empty;
            Special_Requests = string.Empty;
        }

        public Order(int id, int customer_Id, string status, string special_Requests, DateTime created_At, DateTime updated_At)
        {
            Id = id;
            Customer_Id = customer_Id;
            Status = status;
            Special_Requests = special_Requests;
            Created_At = created_At;
            Updated_At = updated_At;
        }
    }
}
