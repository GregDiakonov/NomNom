﻿using NomNomOrders.Models;

namespace NomNomOrders.Utility
{
    public class Pair
    {
        public Dish Dish {  get; set; }
        public int Quantity { get; set; }

        public Pair(Dish dish, int quantity)
        {
            Dish = dish;
            Quantity = quantity;
        }
    }
}
