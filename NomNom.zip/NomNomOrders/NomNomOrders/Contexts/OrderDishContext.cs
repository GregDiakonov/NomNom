﻿using Microsoft.EntityFrameworkCore;
using NomNomOrders.Models;

namespace NomNomOrders.Contexts
{
    /// <summary>
    /// Контекст для блюд, записанных в заказы.
    /// </summary>
    public class OrderDishContext : DbContext
    {
        public DbSet<OrderDish> OrderDishes { get; set; }

        public OrderDishContext()
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql("server=192.168.31.58;uid=register;pwd=Jackson5;database=registration_db",
                    new MySqlServerVersion(new Version(8, 0, 33)));
        }
    }
}
