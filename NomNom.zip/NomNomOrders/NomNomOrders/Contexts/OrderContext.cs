﻿using Microsoft.EntityFrameworkCore;
using NomNomOrders.Models;

namespace NomNomOrders.Contexts
{
    /// <summary>
    /// Контекст для заказов.
    /// </summary>
    public class OrderContext: DbContext
    {
        public DbSet<Order> Orders { get; set; }

        public OrderContext()
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql("server=192.168.31.58;uid=register;pwd=Jackson5;database=registration_db",
                    new MySqlServerVersion(new Version(8, 0, 33)));
        }
    }
}
