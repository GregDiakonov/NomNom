﻿using Microsoft.AspNetCore.Mvc;
using NomNomOrders.Contexts;

namespace NomNomOrders.Controllers
{
    public class MenuController : ControllerBase
    {
        private DishContext _dishContext;

        public MenuController(DishContext dishContext)
        {
            _dishContext = dishContext;
        }

        /// <summary>
        /// Метод, показывающий все доступные для заказа блюда.
        /// </summary>
        /// <returns></returns>
        [HttpGet("ShowMenu")] 
        public ActionResult ShowAllMenu()
        {
            var menu = from dish in _dishContext.Dishes
                       where dish.Is_Available == true
                       select dish;

            return Ok(menu);
        }

    }
}
