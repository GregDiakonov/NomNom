﻿using Microsoft.AspNetCore.Mvc;
using NomNomOrders.Contexts;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

using NomNomOrders.Utility;
using NomNomOrders.Models;
using Microsoft.EntityFrameworkCore;

namespace NomNomOrders.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderController : ControllerBase
    {
        private UserContext _userContext;
        private DishContext _dishContext;
        private OrderContext _orderContext;
        private OrderDishContext _orderDishContext;
        private SessionContext _sessionContext;

        public OrderController(UserContext userContext, DishContext dishContext, OrderContext orderContext, OrderDishContext orderDishContext, SessionContext sessionContext)
        {
            _userContext = userContext;
            _dishContext = dishContext;
            _orderContext = orderContext;
            _orderDishContext = orderDishContext;
            _sessionContext = sessionContext;
        }

        /// <summary>
        /// Метод создания нового заказа.
        /// </summary>
        /// <param name="token">Токен авторизации пользователя (права менеджера не нужны)</param>
        /// <param name="serializedDishList">Сериализованный список блюд, полученный методом MakeDishList.</param>
        /// <param name="specialRequests">Особые пожелания</param>
        /// <param name="status">Статус выполнения заказа</param>
        /// <returns></returns>
        [HttpPost("MakeOrder")]
        public async Task<ActionResult> MakeOrder([Required] string token, [Required] string serializedDishList, string specialRequests = "none", [Required] int status = 1)
        {
            // Проверяем правильность данных.
            if(!ModelState.IsValid)
            {
                return BadRequest("Некоторые из обязательных полей оказались пустыми.");
            }

            string statusString = GetStatusByCode(status);

            if (statusString == "error") {
                return BadRequest("Код статуса должен быть таким: 1 - ожидается, 2 - в работе, 3 - выполнен, 4 - отменён.");
            }

            // Десериализуем введенный список блюд.

            List<Pair>? pairs;
            
            try
            {
                pairs = JsonConvert.DeserializeObject<List<Pair>>(serializedDishList);
            }
            catch (Exception ex)
            {
                return BadRequest("Десериализация записанных в строку блюд и их количеств провалилась.");
            }

            if(pairs == null || pairs.Count == 0) {
                return BadRequest("В списке блюд не оказалось... блюд?");
            }

            // Проверяем токен авторизации пользователя.
            Session? thisSession = await _sessionContext.Sessions.FirstOrDefaultAsync(x => x.Session_Token == token);

            if(thisSession == null) {
                return BadRequest("Указанный вами токен никем не используется.");
            }

            if(thisSession.Expires_At < DateTime.Now)
            {
                return BadRequest("Указанный вами токен уже истёк");
            }

            // Создаём заказ.

            Order newOrder = new Order();

            newOrder.Customer_Id = thisSession.User_Id;
            newOrder.Status = statusString;
            newOrder.Special_Requests = specialRequests;
            newOrder.Created_At = DateTime.Now;
            newOrder.Updated_At = DateTime.Now;

            // ЗАПИСЫВАЕМ заказ, чтобы база данных сама сгенерировала ему id.

            _orderContext.Orders.Add(newOrder);

            await _orderContext.SaveChangesAsync();

            // Получив id заказа, можно создавать связанные с ним OrderDish.

            newOrder = await _orderContext.Orders.OrderBy(x => x.Id).LastAsync();   

            for(int i = 0; i < pairs.Count; i++)
            {
                // Создаём OrderDish, попутно проверяя все данные и изменяя количество блюд в БД.
                OrderDish newDish = ParsePair(pairs[i], newOrder.Id);
                Dish? takenDish = _dishContext.Dishes.Find(pairs[i].Dish.Id);

                if(takenDish == null)
                {
                    return BadRequest("Не все блюда из заказа найдены в базе данных.");
                }

                if(!takenDish.Is_Available)
                {
                    return BadRequest("Это блюдо недоступно к заказу.");
                }

                if(takenDish.Quantity < pairs[i].Quantity)
                {
                    return BadRequest($"На складе нет такого количества блюда: {takenDish.Name}");
                }

                takenDish.Quantity -= pairs[i].Quantity;

                if(takenDish.Quantity == 0)
                {
                    takenDish.Is_Available = false;
                }

                _orderDishContext.OrderDishes.Add(newDish);
            }

            _dishContext.SaveChanges();
            _orderDishContext.SaveChanges();

            return Ok(newOrder);
        }
        
        /// <summary>
        /// Обновление статусов.
        /// Работает ВРУЧНУЮ. 
        /// Обновляет статусы, если прошло 15 минут.
        /// </summary>
        /// <returns></returns>
        [HttpPut("UpdateOrderStatuses")]
        public async Task<ActionResult> UpdateOrderStatuses()
        {
            var OrdersAtWork = from order in _orderContext.Orders
                               where ((order.Status == "Pending" || order.Status == "At work") && order.Updated_At < DateTime.Now.AddMinutes(-15))
                               select order;

            foreach(Order order in OrdersAtWork)
            {
                if(order.Status == "Pending")
                {
                    order.Status = "At work";
                }

                if(order.Status == "At work")
                {
                    order.Status = "Done";
                }
            }

            await _orderContext.SaveChangesAsync();

            return Ok();
        }

        /// <summary>
        /// Метод чтения информации о заказе по его id.
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        [HttpGet("OrderByIndex")]
        public ActionResult GetOrderbyIndex([Required] int index)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Не указан id заказа!");
            }

            Order? thisOrder = _orderContext.Orders.Find(index);

            if(thisOrder == null)
            {
                return NotFound("Не найдено заказа с таким id.");
            }

            return Ok(thisOrder);
        }

        private OrderDish ParsePair(Pair pair, int orderId)
        {
            OrderDish newOrderDish = new OrderDish();

            newOrderDish.Dish_Id = pair.Dish.Id;
            newOrderDish.Order_Id = orderId;
            newOrderDish.Price = pair.Dish.Price;
            newOrderDish.Quantity = pair.Dish.Quantity;

            return newOrderDish;
        }

        private string GetStatusByCode(int code)
        {
            switch (code)
            {
                case 1:
                    return "Pending";
                case 2:
                    return "At work";
                case 3:
                    return "Done";
                case 4:
                    return "Cancelled";
                default:
                    return "Error";
            }
        }
    }
}
