﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

using NomNomOrders.Contexts;
using NomNomOrders.Models;
using NomNomOrders.Utility;

namespace NomNomOrders.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DebugController : ControllerBase
    {
        private DishContext _dishContext;
        private OrderContext _orderContext;
        private OrderDishContext _orderDishContext;

        public DebugController(DishContext dishContext, OrderContext orderContext, OrderDishContext orderDishContext)
        {
            _dishContext = dishContext;
            _orderContext = orderContext;
            _orderDishContext = orderDishContext;
        }

        /// <summary>
        /// Метод используется для создания сериализованной коллекции блюд и их требуемого количества.
        /// </summary>
        /// <param name="dishes">Блюда в заказе</param>
        /// <param name="quantities">Количество каждого блюда в заказе</param>
        /// <returns></returns>
        [HttpGet("list")]
        public ActionResult<string> MakeDishList([Required]string dishes, [Required]string quantities)
        {
            // Проверяем поля на заполненность.
            if(!ModelState.IsValid)
            {
                return BadRequest("Вы не указали одно из полей в методе.");
            }

            // Проверяем ввод на корректность.

            string[] dishNames = dishes.Split(", ");
            string[] quantityStrings = quantities.Split(", ");

            if(dishNames.Length != quantityStrings.Length)
            {
                return BadRequest("Один список параметров оказался больше другого.");
            }

            List<Dish> dishList = new List<Dish>();
            List<int> quantityList = new List<int>();

            for(int i = 0; i <  dishNames.Length; i++)
            {
                Dish? newDish = _dishContext.Dishes.FirstOrDefault(x => x.Name == dishNames[i]);

                if(newDish == null)
                {
                    return BadRequest($"Блюдо с именем {dishNames[i]} не найдено в базе данных.");
                }

                dishList.Add(newDish);

                int quantity = 0;

                if (!int.TryParse(quantityStrings[i], out quantity))
                {
                    return BadRequest($"{quantityStrings} - не число, но оказалось среди значений количеств блюд в заказе.");
                }

                if(newDish.Quantity < quantity)
                {
                    return BadRequest($"Блюдо с именем {dishNames[i]} есть в базе данных, но его только {newDish.Quantity}, а не {quantity}.");
                }

                quantityList.Add(quantity);
            }

            // Создаём пары из блюда и количества блюда.

            List<Pair> pairsList = new List<Pair>();
            
            for(int i = 0; i < dishNames.Length; i++)
            {
                Pair newPair = new Pair(dishList[i], quantityList[i]);
                pairsList.Add(newPair);
            }

            // Сериализируем данные и возвращаем их.
            string jsonPairs = JsonConvert.SerializeObject(pairsList);
            return Ok(jsonPairs);
        }

        [HttpGet("AllDishes")]
        public ActionResult GetAllDishes()
        {
            var allDishes = from dish in _dishContext.Dishes
                            select dish;

            return Ok(allDishes);
        }

        [HttpGet("AllOrders")]
        public ActionResult GetAllOrders()
        {
            var allOrders = from order in _orderContext.Orders
                            select order;

            return Ok(allOrders);
        }

        [HttpGet("AllOrderedDishes")]
        public ActionResult GetAllOrderDishes()
        {
            var allOrderDishes = from orderDish in _orderDishContext.OrderDishes
                                 select orderDish;

            return Ok(allOrderDishes);
        }
    }
}
