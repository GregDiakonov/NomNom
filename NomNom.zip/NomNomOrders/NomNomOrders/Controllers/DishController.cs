﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

using NomNomOrders.Contexts;
using NomNomOrders.Models;
using Microsoft.EntityFrameworkCore;

namespace NomNomOrders.Controllers
{
    /// <summary>
    /// Здесь приведены CRUD-методы для изменения базы данных блюд.
    /// </summary>
    public class DishController : ControllerBase
    {
        private DishContext _dishСontext;
        private SessionContext _sessionContext;
        private UserContext _userContext;

        public DishController(DishContext dishContext, SessionContext sessionContext, UserContext userContext)
        {
            _dishСontext = dishContext;
            _sessionContext = sessionContext;
            _userContext = userContext;
        }

        /// <summary>
        /// Создание блюда.
        /// </summary>
        /// <param name="token">Токен авторизации</param>
        /// <param name="name">Название блюда</param>
        /// <param name="description">Описание блюда</param>
        /// <param name="price">Цена блюда</param>
        /// <param name="quantity">Количество блюда</param>
        /// <param name="is_available">Доступность блюда</param>
        /// <returns></returns>
        [HttpPost("create_dish")]
        public async Task<ActionResult> AddDish([Required] string token, [Required] string name, string description, [Required] decimal price, [Required] int quantity, [Required] bool is_available)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest("Некоторые из обязательных полей оказались пустыми!");
            }

            // В каждом методе этого контроллера мы проверяем токен авторизации.
            if(!CheckToken(token))
            {
                return BadRequest("Ошибка токена: либо такого токена нет, либо он назначен пользователю без прав менеджера.");
            }

            if(name == null) {
                return BadRequest("Поле name обязательно к заполнению.");
            }

            Dish newDish = new Dish();

            newDish.Name = name;
            newDish.Description = description;
            newDish.Price = price;
            newDish.Quantity = quantity;
            newDish.Is_Available = is_available;
            newDish.Created_At = DateTime.Now;
            newDish.Updated_At = DateTime.Now;

            _dishСontext.Dishes.Add(newDish);

            await _dishСontext.SaveChangesAsync();

            return Ok(newDish);
        }

        /// <summary>
        /// Прочитать блюдо по его названию
        /// </summary>
        /// <param name="token">Токен авторизации менеджера</param>
        /// <param name="name">Название блюда</param>
        /// <returns></returns>
        [HttpGet("read_dish")]
        public async Task<ActionResult> GetDishByName([Required] string token, [Required] string name)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest("Некоторые из обязательных полей оказались пустыми!");
            }

            // Проверка токена.
            if (!CheckToken(token))
            {
                return BadRequest("Ошибка токена: либо такого токена нет, либо он назначен пользователю без прав менеджера.");
            }

            Dish? thisDish = await _dishСontext.Dishes.FirstOrDefaultAsync(x => x.Name == name);

            if(thisDish == null)
            {
                return NotFound("Блюда с таким названием не найдено.");
            }

            return Ok(thisDish);
        }

        /// <summary>
        /// Обновление информации о блюде.
        /// </summary>
        /// <param name="token">Токен авторизации менеджера</param>
        /// <param name="oldName">Имя, под которым блюдо уже записано в базу данных</param>
        /// <param name="name">Имя, если вы хотите его изменить.</param>
        /// <param name="description">Описание, если вы хотите его изменить</param>
        /// <param name="isAvailableString">Статус доступности, если вы хотите его изменить</param>
        /// <param name="price">Цена, если вы хотите её изменить</param>
        /// <param name="quantity">Количество, если вы хотите его изменить</param>
        /// <returns></returns>
        [HttpPut("update_dish")]
        public async Task<ActionResult> UpdateDish([Required] string token, [Required] string oldName, string name, string description, string isAvailableString, decimal price = -1, int quantity = -1)
        {
            if (!CheckToken(token))
            {
                return BadRequest("Ошибка токена: либо такого токена нет, либо он назначен пользователю без прав менеджера.");
            }

            // Чтобы дать понять, что у пользователя не было намерения изменять то или иное поле,
            // можно назначить его значение какой-нибудь не имеющей смысла для этого поля величине.
            // Например: цена и количество блюд не может быть отрицательным.
            Dish? thisDish = _dishСontext.Dishes.FirstOrDefault(x => x.Name == oldName);

            if(thisDish == null)
            {
                return BadRequest("Не найдено блюд с таким именем!");
            }

            if(name != null)
            {
                thisDish.Name = name;
            }

            if(description != null)
            {
                thisDish.Description = description;
            }

            if(isAvailableString != null)
            {
                if(isAvailableString == "true")
                {
                    thisDish.Is_Available = true;
                }

                if(isAvailableString == "false")
                {
                    thisDish.Is_Available = false;
                }
            }

            if(price >= 0)
            {
                thisDish.Price = price;
            }

            if(quantity >= 0)
            {
                thisDish.Quantity = quantity;
            }

            thisDish.Updated_At = DateTime.Now;

            await _dishСontext.SaveChangesAsync();

            return Ok(thisDish);
        }

        /// <summary>
        /// Метод удаления блюда.
        /// </summary>
        /// <param name="token">Токен авторизации</param>
        /// <param name="name">Название удаляемого блюда</param>
        /// <returns></returns>
        [HttpDelete("delete_dish")]
        public async Task<ActionResult> DeleteDishByName([Required] string token, [Required] string name) {
            if(!ModelState.IsValid)
            {
                return BadRequest("Некоторые из обязательных полей оказались пустыми.");
            }

            if (!CheckToken(token))
            {
                return BadRequest("Ошибка токена: либо такого токена нет, либо он назначен пользователю без прав менеджера.");
            }

            Dish? dishToDelete = await _dishСontext.Dishes.FirstOrDefaultAsync(x => x.Name == name);

            if(dishToDelete == null)
            {
                return NotFound("Блюда с таким названием не найдено.");
            }

            _dishСontext.Dishes.Remove(dishToDelete);

            await _dishСontext.SaveChangesAsync();

            return Ok("Удаление прошло успешно!");
        }

        /// <summary>
        /// Общий для всех методов этого контроллера метод проверки токена авторизации.
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        private bool CheckToken(string token)
        {
            Session? thisSession = _sessionContext.Sessions.FirstOrDefault(x => x.Session_Token == token);

            if(thisSession == null)
            {
                return false;
            }

            User? thisUser = _userContext.Users.Find(thisSession.User_Id);

            if(thisUser == null)
            {
                return false;
            }

            if(thisUser.Role == "Manager" && thisSession.Expires_At > DateTime.Now)
            {
                return true;
            }

            return false;
        }
    }
}
