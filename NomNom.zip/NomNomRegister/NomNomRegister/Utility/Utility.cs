﻿using System;
using System.Security.Claims;
using System.Security.Cryptography;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;

namespace NomNomRegister.Utility
{
    public static class Utility
    {
        private static string[] knownEmails = { "@gmail.com", "@yahoo.com", "@outlook.com", "@aol.com", "@icloud.com",
                                                "@zmtpost.com", "@protonmail.com", "@gmx.com", "@yandex.com", "@hotmail.com",
                                                "@live.com", "@cox.net", "@att.net", "@verizon.net", "@comcast.net", "@sbcglobal.net",
                                                "@aim.com", "@charter.net", "@netscape.net", "@mail.ru"};

        private static SymmetricSecurityKey secretKey;
        private static SigningCredentials credentials;

        public static bool CheckEmail(string email)
        {
            for (int i = 0; i < knownEmails.Length; i++)
            {
                if (email.Contains(knownEmails[i]))
                {
                    return true;
                }
            }

            return false;
        }

        public static string HashPassword(string password)
        {
            SHA256 sha256 = SHA256.Create();
            byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(password);
            byte[] hashedBytes = sha256.ComputeHash(inputBytes);
            string hashed = BitConverter.ToString(hashedBytes).Replace("-", "");

            return hashed;
        }

        public static string MakeToken(string nickname, string role)
        {
            if (secretKey == null)
            {
                SetKeyAndCredentials();
            }

            Claim[] claims = new Claim[] { new Claim("nickname", nickname), new Claim("role", role) };
            JwtSecurityToken token = new JwtSecurityToken(issuer: "needa.ru", audience: "needa.ru",
                    claims: claims, expires: DateTime.Now.AddDays(1), signingCredentials: credentials);

            string tokenStr = new JwtSecurityTokenHandler().WriteToken(token);

            return tokenStr;
        }

        private static void SetKeyAndCredentials()
        {
            secretKey = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes("needamostsecretandimpeccablyunknownkey"));
            credentials = new SigningCredentials(secretKey, SecurityAlgorithms.HmacSha256);
        }
    }
}
