﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NomNomRegister.Contexts;
using NomNomRegister.Models;
using NomNomRegister.Utility;
using System.Text;
using System.Security.Cryptography;
using System.ComponentModel.DataAnnotations;

namespace NomNomRegister.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RegistrationController : ControllerBase
    {
        private UserContext _users;
        private SessionContext _sessions;

        public RegistrationController(UserContext users, SessionContext sessions)
        {
            _users = users;
            _sessions = sessions;
        }

        /// <summary>
        /// Метод обработки попытки регистрации.
        /// </summary>
        /// <param name="nickname">Логин</param>
        /// <param name="email">Почтовый ящик</param>
        /// <param name="password">Пароль</param>
        /// <returns></returns>
        [HttpPost("RegisterAttempt")]
        public async Task<ActionResult> Register([Required] string nickname, [Required] string email, [Required] string password)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest("Некоторые поля оказались пустыми.");
            }

            if (!Utility.Utility.CheckEmail(email))
            {
                return BadRequest("Указанный почтовый ящик не правилен.");
            }

            if (_users == null)
            {
                return NoContent();
            }

            User? namesake = await _users.Users.FirstOrDefaultAsync(x => x.Nickname == nickname);

            if (namesake != null)
            {
                return BadRequest("Этот логин уже занят.");
            }

            namesake = await _users.Users.FirstOrDefaultAsync(x => x.Email == email);

            if (namesake != null)
            {
                return BadRequest("Этот почтовый ящик уже занят.");
            }

            string hashed = Utility.Utility.HashPassword(password);

            Console.WriteLine(hashed);

            User newUser = new User();

            newUser.Nickname = nickname;
            newUser.Email = email;
            newUser.Password_Hash = hashed;
            newUser.Role = "Customer";
            newUser.Created = DateTime.Now;
            newUser.Updated = newUser.Created;

            _users.Users.Add(newUser);
            await _users.SaveChangesAsync();

            return Ok(newUser);
        }

        /// <summary>
        /// Метод обработки попытки авторизации.
        /// </summary>
        /// <param name="nickname">Логин</param>
        /// <param name="password">Пароль</param>
        /// <returns></returns>
        [HttpPost("AuthorizationAttempt")]
        public async Task<ActionResult> Authorize([Required] string nickname, [Required] string password)
        {
            if (nickname == null || password == null)
            {
                return BadRequest("Некоторые поля оказались пустыми!");
            }

            if (_users == null || _sessions == null)
            {
                return NotFound();
            }

            User? userByNickname = await _users.Users.FirstOrDefaultAsync(x => x.Nickname == nickname);

            if (userByNickname == null)
            {
                return BadRequest("Пользователь с таким логином не найден в базе данных.");
            }

            string hashed = Utility.Utility.HashPassword(password);

            if (userByNickname.Password_Hash != hashed)
            {
                return BadRequest("Пароли не совпадают.");
            }

            // Смысл метода в том, чтобы создать объект-сессию.
            // Генерируем токен, создаём объект-сессию, записываем в базу данных.
            // Таким образом, любому активному пользователю будет однозначно задана своя сессия.

            string tokenString = Utility.Utility.MakeToken(nickname, userByNickname.Role);

            Session newSession = new Session();

            newSession.Session_Token = tokenString;
            newSession.User_Id = userByNickname.Id;
            newSession.Expires_At = DateTime.Now.AddDays(1);

            _sessions.Sessions.Add(newSession);
            _sessions.SaveChanges();

            return Ok(newSession);
        }

        /// <summary>
        /// С помощью этого метода можно узнать пользователя по его токену авторизации.
        /// </summary>
        /// <param name="token">Токен авторизации.</param>
        /// <returns></returns>
        [HttpGet("GetInfoByToken")]
        public async Task<ActionResult<User>> GetInfo([Required] string token)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Некоторые поля оказались пустыми.");
            }

            Session? thisSession = await _sessions.Sessions.FirstOrDefaultAsync<Session>(x => x.Session_Token == token);

            if (thisSession == null)
            {
                return NotFound("Не найдено сессий с таким токеном!");
            }

            User? thisUser = await _users.Users.FindAsync(thisSession.User_Id);

            if (thisUser == null)
            {
                return NotFound("Не найден пользователь с таким ID. Что-то пошло сильно не так.");
            }

            return Ok(thisUser);
        }

        /// <summary>
        /// Метод, который позволяет установить роль пользователю.
        /// </summary>
        /// <param name="nickname">Логин пользователя</param>
        /// <param name="roleCode">Код новой роли пользователя: 1 - клиент, 2 - повар, 3 - менеджер.</param>
        /// <returns></returns>
        [HttpPut("AssignRole")]
        public async Task<ActionResult> AssignRole([Required] string nickname, [Required] int roleCode)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Некоторые поля оказались пустыми.");
            }

            User? thisUser = await _users.Users.FirstOrDefaultAsync(x => x.Nickname == nickname);

            if (thisUser == null)
            {
                return BadRequest("Не найдено пользователя с таком логином!");
            }

            string newRole;

            switch (roleCode)
            {
                case 1:
                    newRole = "Customer";
                    break;
                case 2:
                    newRole = "Chef";
                    break;
                case 3:
                    newRole = "Manager";
                    break;
                default:
                    return BadRequest("Введите правильный код роли: 1 - клиент, 2 - шеф, 3 - менеджер.");
            }

            thisUser.Role = newRole;
            _users.SaveChanges();

            return Ok(thisUser);
        }

        /// <summary>
        /// Метод проверяет токен авторизации и выдаёт новый, если старый скоро истечёт.
        /// </summary>
        /// <param name="token">Токен авторизации</param>
        /// <returns></returns>
        [HttpPut("{CheckToken}")]
        public async Task<ActionResult> CheckToken([Required] string token)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Некоторые поля оказались пустыми.");
            }

            Session? thisSession = _sessions.Sessions.FirstOrDefault(x => x.Session_Token == token);

            if (thisSession == null)
            {
                return NotFound("Сессии с таким токеном не найдено");
            }

            if (thisSession.Expires_At < DateTime.Now)
            {
                return BadRequest("Истёк срок годности токена.");
            }

            // Если токен скоро истечёт, выдадим пользователю новый.
            if (thisSession.Expires_At < DateTime.Now.AddHours(6))
            {
                User? thisUser = await _users.Users.FindAsync(thisSession.User_Id);

                if (thisUser == null)
                {
                    return BadRequest("Не нашлось пользователя с ID из сессии. Что-то пошло сильно не так.");
                }

                string newTokenString = Utility.Utility.MakeToken(thisUser.Nickname, thisUser.Role);
                thisSession.Session_Token = newTokenString;
                _sessions.SaveChanges();

                return Ok("Токен действителен и был заменён на более новый.");
            }

            return Ok("Токен действителен");
        }

        /// <summary>
        /// Дебаг-метод, позволяющий очистить обе базы данных от данных.
        /// </summary>
        /// <returns>Результат попытки</returns>
        [HttpDelete("delete_all")]
        public async Task<ActionResult> Purge()
        {
            if (_users.Users == null || _sessions.Sessions == null)
            {
                return NotFound();
            }

            var userRows = from user in _users.Users
                           select user;

            if (userRows.Count() > 0)
            {
                foreach (var row in userRows)
                {
                    _users.Users.Remove(row);
                }

                _users.SaveChanges();
            }

            var sessionRows = from session in _sessions.Sessions
                              select session;

            if (sessionRows.Count() > 0)
            {
                foreach (var row in sessionRows)
                {
                    _sessions.Sessions.Remove(row);
                }

                _sessions.SaveChanges();
            }

            return Ok();
        }

        /// <summary>
        /// Метод находит истёкшие сессии и удаляет их.
        /// </summary>
        /// <returns></returns>
        [HttpDelete("delete_expired")]
        public async Task<ActionResult> PurgeExpiredSessions()
        {
            if (_sessions == null)
            {
                return NotFound();
            }

            var expiredSessions = from session in _sessions.Sessions
                                  where session.Expires_At < DateTime.Now
                                  select session;

            if (expiredSessions.Count() > 0)
            {
                foreach (Session session in expiredSessions)
                {
                    _sessions.Sessions.Remove(session);
                }

                _sessions.SaveChanges();
                return Ok("Просроченные сессии обнаружены и удалены!");
            }

            return Ok("Просроченных сессий не обнаружено.");
        }
    }
}

