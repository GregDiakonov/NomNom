﻿using Microsoft.EntityFrameworkCore;

using NomNomRegister.Models;

namespace NomNomRegister.Contexts
{
    public class UserContext : DbContext
    {
        public DbSet<User> Users { get; set; }

        public UserContext()
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql("server=192.168.31.58;uid=register;pwd=Jackson5;database=registration_db",
                    new MySqlServerVersion(new Version(8, 0, 33)));
        }
    }
}
