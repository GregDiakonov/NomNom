﻿using Microsoft.EntityFrameworkCore;
using NomNomRegister.Models;

namespace NomNomRegister.Contexts
{
    public class SessionContext : DbContext
    {
        public DbSet<Session> Sessions { get; set; }

        public SessionContext()
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql("server=192.168.31.58;uid=register;pwd=Jackson5;database=registration_db",
                    new MySqlServerVersion(new Version(8, 0, 33)));
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Session>().ToTable("sessions");
        }
    }
}
