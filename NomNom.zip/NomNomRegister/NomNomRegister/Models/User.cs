﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NomNomRegister.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }
        public string Nickname { get; set; }
        public string Email { get; set; }
        public string Password_Hash { get; set; }
        public string Role { get; set; }
        public DateTime Created { get; set; }
        public DateTime Updated { get; set; }

        public User() { }

        public User(int id, string nickname, string email, string password_Hash, string role, DateTime created, DateTime updated)
        {
            Id = id;
            Nickname = nickname;
            Email = email;
            Password_Hash = password_Hash;
            Role = role;
            Created = created;
            Updated = updated;
        }
    }
}