﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NomNomRegister.Models
{
    public class Session
    {
        [Key]
        public int Id { get; set; }
        public int User_Id { get; set; }
        public string Session_Token { get; set; }

        public DateTime Expires_At { get; set; }

        public Session() { }

        public Session(int id, int user_Id, string session_Token, DateTime expires_At)
        {
            Id = id;
            User_Id = user_Id;
            Session_Token = session_Token;
            Expires_At = expires_At;
        }
    }
}
